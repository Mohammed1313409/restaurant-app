import { useRouter } from 'expo-router';
import React from 'react';
import { Button, FlatList, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { useCart } from '../CartContext';

export default function CartScreen() {
    const router = useRouter();
    const { cartItems, updateQuantity, removeItem } = useCart();



    const total = cartItems.reduce(
        (sum: number, item: { price: number; quantity: number }) =>
            sum + item.price * item.quantity,
        0
    );

    const renderItem = ({ item }: { item: any }) => (
        <View style={styles.item}>
            <Text style={styles.name}>{item.name}</Text>
            <Text>Price: ${item.price}</Text>
            <View style={styles.controls}>
                <TouchableOpacity onPress={() => updateQuantity(item.id, -1)}>
                    <Text style={styles.controlButton}>-</Text>
                </TouchableOpacity>
                <Text style={styles.quantity}>{item.quantity}</Text>
                <TouchableOpacity onPress={() => updateQuantity(item.id, 1)}>
                    <Text style={styles.controlButton}>+</Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={() => removeItem(item.id)}>
                    <Text style={styles.remove}>Remove</Text>
                </TouchableOpacity>
            </View>
        </View>
    );

    return (
        <View style={styles.container}>
            <FlatList
                data={cartItems}
                keyExtractor={(item) => item.id}
                renderItem={renderItem}
                ListEmptyComponent={<Text>Your cart is empty.</Text>}
            />

            <Text style={styles.total}>Total: ${total.toFixed(2)}</Text>

            <View style={styles.paymentButtons}>
                <Button title="Go to Checkout" onPress={() => router.push('/checkout')} />
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 16,
    },
    item: {
        marginBottom: 20,
        padding: 10,
        borderWidth: 1,
        borderColor: '#ccc',
        borderRadius: 8,
    },
    name: {
        fontWeight: 'bold',
        fontSize: 16,
    },
    controls: {
        flexDirection: 'row',
        alignItems: 'center',
        marginTop: 10,
    },
    controlButton: {
        fontSize: 20,
        paddingHorizontal: 10,
        color: 'blue',
    },
    remove: {
        color: 'red',
        marginLeft: 10,
    },
    quantity: {
        fontSize: 16,
        marginHorizontal: 10,
    },
    total: {
        fontSize: 18,
        fontWeight: 'bold',
        textAlign: 'right',
        marginVertical: 10,
    },
    paymentButtons: {
        gap: 10,
    },
});
