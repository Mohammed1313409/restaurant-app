import React, { useState } from 'react';
import { Button, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { useCart } from '../CartContext';


export default function ItemScreen() {
    const [comment, setComment] = useState('');
    const [reviews, setReviews] = useState([
        { user: 'Ali', comment: 'Amazing taste!' },
        { user: 'Sara', comment: 'Would order again.' },
    ]);

    const { addToCart } = useCart();

    const item = {
        id: '1',
        name: 'Grilled Salmon',
        category: 'Seafood',
        description: 'Delicious grilled salmon with herbs and lemon.',
        ingredients: ['Salmon', 'Lemon', 'Garlic', 'Olive oil'],
        rating: 4.5,
        price: 30,
    };

    const handleAddComment = () => {
        if (comment.trim() !== '') {
            setReviews([...reviews, { user: 'You', comment }]);
            setComment('');
        }
    };

    const handleAddToCart = () => {
        addToCart({ id: item.id, name: item.name, price: item.price });
        alert('Added to cart');
        console.log('Cart item added:', { id: item.id, name: item.name, price: item.price });
    };

    return (
        <ScrollView style={styles.container}>
            <Text style={styles.name}>{item.name}</Text>
            <Text style={styles.category}>{item.category}</Text>
            <Text style={styles.description}>{item.description}</Text>

            <Text style={styles.section}>Ingredients:</Text>
            {item.ingredients.map((ing, index) => (
                <Text key={index}>- {ing}</Text>
            ))}

            <Text style={styles.section}>Rating: ⭐ {item.rating}</Text>

            <Text style={styles.section}>Reviews:</Text>
            {reviews.map((rev, index) => (
                <Text key={index}>• {rev.user}: {rev.comment}</Text>
            ))}

            <Text style={styles.section}>Add Your Review:</Text>
            <TextInput
                placeholder="Write a comment..."
                value={comment}
                onChangeText={setComment}
                style={styles.input}
            />
            <Button title="Submit Comment" onPress={handleAddComment} />

            <View style={{ marginTop: 20 }}>
                <Button title="Add to Cart" onPress={handleAddToCart} />
            </View>
        </ScrollView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 24,
        backgroundColor: '#fff',
    },
    name: {
        fontSize: 24,
        fontWeight: 'bold',
    },
    category: {
        fontSize: 16,
        color: 'gray',
    },
    description: {
        marginTop: 10,
        fontSize: 16,
    },
    section: {
        marginTop: 20,
        fontWeight: 'bold',
    },
    input: {
        borderWidth: 1,
        borderColor: '#ccc',
        padding: 10,
        marginTop: 10,
        marginBottom: 10,
        borderRadius: 6,
    },
});
