import { useRouter } from 'expo-router';
import React from 'react';
import { Button, StyleSheet, Text, TextInput, View } from 'react-native';

export default function LoginScreen() {
    const router = useRouter();

    return (
        <View style={styles.container}>
            <Text style={styles.title}>Welcome Back!</Text>

            <TextInput
                placeholder="Email"
                style={styles.input}
                keyboardType="email-address"
            />
            <TextInput
                placeholder="Password"
                style={styles.input}
                secureTextEntry
            />

            <Button
                title="Login"
                onPress={() => router.push('/home')}
                color="#007AFF"
            />

            <Text style={styles.signupText}>
                Don't have an account?{' '}
                <Text style={{ color: 'blue' }} onPress={() => router.push('/signup')}>
                    Sign up
                </Text>
            </Text>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 24,
        justifyContent: 'center',
    },
    title: {
        fontSize: 22,
        fontWeight: 'bold',
        textAlign: 'center',
        marginBottom: 24,
    },
    input: {
        borderWidth: 1,
        borderColor: '#aaa',
        borderRadius: 6,
        padding: 10,
        marginBottom: 12,
    },
    signupText: {
        marginTop: 16,
        textAlign: 'center',
    },
});
